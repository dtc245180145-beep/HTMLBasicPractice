# Thực hành HTML cơ bản: Vịnh Hạ Long

Bài thực hành sử dụng các thẻ HTML cơ bản:
- `<h1>`: tiêu đề chính
- `<p>`: các đoạn văn bản
- `<img>`: hình ảnh với thuộc tính `src`, `alt`, `width`
- `<a>`: liên kết đến Wikipedia

## Cách xem
Mở tệp `halong_bay.html` bằng trình duyệt web. Cần kết nối Internet để tải hình ảnh từ URL bên ngoài.
